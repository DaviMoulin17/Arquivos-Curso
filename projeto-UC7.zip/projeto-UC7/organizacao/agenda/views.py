from django.shortcuts import render
from .models import Tarefa

def listar_tarefas(request):
    tarefas = Tarefa.objects.all().order_by('data')
    return render(request, 'agenda/lista.html', {'tarefas': tarefas})

def home(request):
    return render(request, 'agenda/main.html')

