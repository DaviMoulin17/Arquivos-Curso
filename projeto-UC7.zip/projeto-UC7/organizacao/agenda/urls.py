from django.urls import path
from . import views

app_name = 'agenda'
urlpatterns = [
    path('main/', views.home, name='main'),
    path('tarefas/', views.listar_tarefas, name='listar_tarefas'),
]
